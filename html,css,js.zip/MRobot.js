let $ = document;
// header
let fisrtNavigation = $.querySelectorAll(".nav")[0];
let lastNavigation = $.querySelectorAll(".nav")[5];
let navListPages = $.querySelector(".nav_list-pages");
let navListProduct = $.querySelector(".nav_list-product");
let loginBasketBox = $.querySelector(".login_basket_box");
let basket_nav_clicked = $.querySelector(".basket_nav_clicked");
let basket_nav__clicked___top____btn = $.querySelector(
  ".basket_nav__clicked___top____btn"
);
let headerTop = $.querySelector(".header_top");

fisrtNavigation.addEventListener(
  "mouseover",
  () => (navListPages.style.display = "block")
);
fisrtNavigation.addEventListener(
  "mouseleave",
  () => (navListPages.style.display = "none")
);
lastNavigation.addEventListener(
  "mouseover",
  () => (navListProduct.style.display = "block")
);
lastNavigation.addEventListener(
  "mouseleave",
  () => (navListProduct.style.display = "none")
);

loginBasketBox.addEventListener("click", () => {
  basket_nav_clicked.style.right = "0";
});
basket_nav__clicked___top____btn.addEventListener(
  "click",
  () => (basket_nav_clicked.style.left = "-30rem")
);
let i;
window.addEventListener("scroll", () => {
  if (window.scrollY > 50) {
    headerTop.style.transform = "translateY(-100%)";
  } else {
    headerTop.style.transform = "translateY(0)";
  }
});

// main slider

let ImageSrc = [
  { id: 1, src: "./Assets/images/main_slider-2.gif" },
  { id: 2, src: "./Assets/images/main_slider-1.webp" },
  { id: 3, src: "./Assets/images/main_slider-3.webp" },
  { id: 4, src: "./Assets/images/main_slider-4.webp" },
];
let prevBtn = $.querySelector(".slider_previous");
let nextBtn = $.querySelector(".slider_next");
let sliderImage = $.querySelector(".slider_image");
let sliderNodes = $.querySelectorAll(".slider_node");
let showImageWithID = 1;

function updateActiveClass() {
  sliderNodes.forEach((node) => node.classList.remove("slider_active"));
}

let currentNode = Array.from(sliderNodes).find(
  (node) => node.dataset.id === showImageWithID
);
if (currentNode) {
  currentNode.classList.add("slider_active");
}

function changeImage() {
  ImageSrc.forEach((image) => {
    if (image.id === showImageWithID) {
      sliderImage.src === image.src;
    }
  });
  updateActiveClass();
}

function prevImageHandler() {
  showImageWithID++;
  changeImage();
}

function nextImageHandler() {
  showImageWithID--;
  changeImage();
}

setInterval(() => {
  prevImageHandler();
}, 4000);

function changeImage() {
  ImageSrc.forEach((image) => {
    if (showImageWithID === image.id) {
      sliderImage.src = image.src;
    }

    if (showImageWithID < 1) {
      showImageWithID = 4;
    }

    if (showImageWithID > 4) {
      showImageWithID = 1;
    }
  });
}

// sliderNodes.forEach(node => {
//  node.classList.remove("slider_active")
//  console.log(node.dataset.id)
//  console.log(showImageWithID)
//  let result = node.dataset.id === showImageWithID
// console.log(result)
// })

prevBtn.addEventListener("click", prevImageHandler);
nextBtn.addEventListener("click", nextImageHandler);

// timer

let hourResult = $.querySelectorAll(".time_hour");
let minResult = $.querySelectorAll(".time_min");
let secResult = $.querySelectorAll(".time_sec");

let hour = null;
let min = null;
let sec = null;

hourResult.forEach((hourRes) => {
  minResult.forEach((minRes) => {
    secResult.forEach((secRes) => {
      hour = hourRes.innerHTML;
      min = minRes.innerHTML;
      sec = secRes.innerHTML;
    });
  });
});

setInterval(() => {
  sec--;

  hourResult.forEach((hourRes) => {
    minResult.forEach((minRes) => {
      secResult.forEach((secRes) => {
        if (sec < 0) {
          min--;
          sec = 59;
        }

        if (min < 0) {
          hour--;
          min = 59;
        }

        if (sec < 9 && sec > 0) {
          secRes.classList.add("time_add__zero");
        }

        if (sec > 10) {
          secRes.classList.remove("time_add__zero");
        }

        if (min < 9 && min > 0) {
          minRes.classList.add("time_add__zero");
        }

        if (min > 10) {
          minRes.classList.remove("time_add__zero");
        }

        hourRes.innerHTML = hour;
        minRes.innerHTML = min;
        secRes.innerHTML = sec;
      });
    });
  });
}, 1000);

let footerScroll = $.querySelector("#footer_scroll");

footerScroll.addEventListener("click", () => window.scrollTo(0, 0));

const names = [
  "mohammad",
  "reza",
  "mohammad",
  "amir",
  "reza",
  "mohammad",
  "reza",
  "ali",
  "reza",
];
const nameCounts = names.reduce((acc, name) => {
  if (acc[name]) {
    acc[name] += 1;
  } else {
    acc[name] = 1;
  }
  return acc;
}, {});

console.log(nameCounts);

const products = [
  "lap top",
  "ipad",
  "iphone",
  "flash",
  "lap top",
  "flash",
  "iphone",
  "flash",
  "lap top",
  "flash",
];

let reaptingProducts = products.reduce((pre, curr) => {
  return { ...pre, [curr]: (pre[curr] || 0) + 15 };
}, {});

console.log(reaptingProducts);

function showNavbarMobile() {
  const navsPhone = document.querySelector('.navs_phone');
  if (navsPhone.style.display === "block") {
    navsPhone.style.display = "none";
  } else {
    navsPhone.style.display = "block";
  }
}

// مدیریت منوی موبایل
const mobileMenuBtn = document.querySelector('.nav_mobie_menu svg');
const mobileMenu = document.querySelector('.navs_phone');
const mobileMenuOverlay = document.createElement('div');

mobileMenuOverlay.className = 'mobile-menu-overlay';
document.body.appendChild(mobileMenuOverlay);

mobileMenuOverlay.style.cssText = `
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0,0,0,0.5);
  z-index: 999;
  display: none;
`;

mobileMenuBtn.addEventListener('click', () => {
  mobileMenu.style.display = 'block';
  mobileMenuOverlay.style.display = 'block';
  document.body.style.overflow = 'hidden';
});

mobileMenuOverlay.addEventListener('click', () => {
  mobileMenu.style.display = 'none';
  mobileMenuOverlay.style.display = 'none';
  document.body.style.overflow = '';
});