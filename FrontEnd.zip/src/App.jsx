import { useState } from 'react'
import { useRoutes } from "react-router-dom";
import routes from "./Components/routes.jsx";
import Header from "./Components/header/Header"
import Footer from "./Components/footer/Footer"


function App() {
const routtes = useRoutes(routes);
  return (
    <>
    {/* <Header/> */}
     {routtes}
    {/* <Footer/> */}
    </>
  )
}

export default App
