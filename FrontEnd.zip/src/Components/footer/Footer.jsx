import React from "react";
import "./footer.css";

const Footer = () => {
  return (
  <footer>

  </footer>
  );
};

export default Footer;
