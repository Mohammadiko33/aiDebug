// src/components/Header/Header.jsx
import React from 'react';
import './Header.css';

const Header = () => {

  return (
    <header>
  
    </header>
  );
};

export default Header;